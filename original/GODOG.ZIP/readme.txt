godog java demo

august 7th, 1998 ... around 17:00 

this version is compiled in a terrible rush, after being awake for way too long... 
better versions will follow - please check out our website.

some notes:

* the demo requires about 30MB of memory - this is because of large amount of big
truecolor layers.  

* if you run it with JDK, please allow more than 16MB memory 
with "java -mx99m godog" or "appletviewer -Jmx99m godog.html"

* if you get a VM crash on microsoft VM (ie4), please upgrade to version 3.0.  
we have experienced some serious JIT bugs with 2.0 and 3.0 pre-releases.


cheers

jmagic 

mailto:komplex@jyu.fi
http://www.jyu.fi/komplex
